# Portfolio Muhammad Adira Izzatinnas

Website portofolio pribadi untuk GitHub Pages.

## Struktur
- `index.html` — halaman utama
- `style.css` — desain/responsif
- `app.js` — menu mobile & tahun otomatis
- `CV_Muhammad_Adira.pdf` — CV
- `sertifikat/` — 7 sertifikat PDF

## GitHub Pages
Upload seluruh isi folder ini ke repository:
`izzatinnas.github.io`

Pastikan `index.html` berada di root repository, lalu:
Settings → Pages → Deploy from a branch → `main` → `/ (root)` → Save.
